
# Python Project: Exploratory Data Analysis (EDA)

This project focuses on analyzing grocery shop sales data to uncover trends and insights.

## Objective:
- Identify top-performing products/categories.
- Analyze sales trends (daily, weekly, seasonal).
- Calculate profitability by category.

## Tools:
- **Python Libraries**: Pandas, Matplotlib, Seaborn.

## Files:
- `Grocery_Sales_EDA.ipynb`: Jupyter Notebook with the analysis.

## Dataset:
A mock dataset of grocery sales is used (columns: `Date`, `Product`, `Category`, `Quantity Sold`, `Revenue`, `Cost`, `Stock`).
    