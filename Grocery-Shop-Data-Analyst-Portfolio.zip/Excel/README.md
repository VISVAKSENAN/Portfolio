
# Excel Project: Sales and Expense Tracking

This project uses Excel to track grocery shop sales and expenses.

## Objective:
- Track monthly revenue, expenses, and profit.
- Create pivot tables for product and category performance.
- Visualize data using charts (bar, line, and pie charts).

## Tools:
- **Excel**: Advanced formulas, pivot tables, and charts.

## Files:
- `Grocery_Sales_Analysis.xlsx`: Excel file containing the analysis and visuals.

## Dataset:
Simulated monthly sales and expense data.
    