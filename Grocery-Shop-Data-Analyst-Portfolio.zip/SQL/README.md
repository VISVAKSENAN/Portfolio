
# SQL Project: Grocery Sales Analysis

This project demonstrates the use of SQL for querying and analyzing grocery shop sales and inventory data.

## Objective:
- Calculate total revenue, profit, and average order value.
- Identify low-stock products.
- Analyze sales trends by product category and region.

## Tools:
- **SQL**: Queries written for SQLite/MySQL.

## Files:
- `Grocery_Sales_Queries.sql`: Contains all the SQL queries used for analysis.

## Dataset:
Mock SQL database with tables like `Products`, `Sales`, and `Inventory`.
    