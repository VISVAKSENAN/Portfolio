
# Power BI Project: Interactive Grocery Sales Dashboard

This project involves creating a dynamic Power BI dashboard for managing grocery shop data.

## Objective:
- Visualize sales, profits, and low-stock items.
- Add filters for product categories and time periods.
- Track key performance indicators (KPIs).

## Tools:
- **Power BI**: Interactive dashboard creation.

## Files:
- `Grocery_Sales_Dashboard.pbix`: Power BI dashboard file.
- Screenshots of the dashboard are available in the `Dashboard_Screenshots` folder.

## Dataset:
Simulated grocery sales and inventory data.
    