
# Grocery Shop Data Analyst Portfolio

This portfolio showcases projects completed to demonstrate skills in **Python**, **SQL**, **Power BI**, and **Excel**. 
All projects are designed to reflect real-world grocery shop data analysis tasks.

## Projects Included:
1. **Python**: Exploratory Data Analysis (EDA) on grocery sales data.
2. **SQL**: Querying and analyzing sales and inventory data.
3. **Power BI**: Interactive dashboard for grocery shop management.
4. **Excel**: Sales and expense tracking with pivot tables and charts.

Feel free to explore each folder for more details!
    